library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity regfile is
  generic(
    G_FAULT_INJECT : boolean := false;
    G_SELF_HEAL    : boolean := false
  );
  port (
    clk                 : in  std_logic;
    rst                 : in  std_logic;
    we                  : in  std_logic;
    reg_in_data         : in  std_logic_vector(31 downto 0);
    reg_read_addr1      : in  std_logic_vector(4 downto 0);
    reg_read_addr2      : in  std_logic_vector(4 downto 0);
    reg_write_addr      : in  std_logic_vector(4 downto 0);
    reg_out_data1       : out std_logic_vector(31 downto 0);
    reg_out_data2       : out std_logic_vector(31 downto 0);
    regfile_tmr_error_o : out std_logic;

    fi_rf_mask_i        : in  std_logic_vector(31 downto 0) := (others => '0');
    fi_rf_addr_i        : in  std_logic_vector(4 downto 0)  := (others => '0');
    fi_rf_target_i      : in  std_logic_vector(1 downto 0)  := "00";
    fi_rf_strobe_i      : in  std_logic := '0'
  );
end regfile;

architecture rtl of regfile is

  type mem_t is array (0 to 31) of std_logic_vector(31 downto 0);

  signal regfile_a : mem_t := (others => (others => '0'));
  signal regfile_b : mem_t := (others => (others => '0'));
  signal regfile_c : mem_t := (others => (others => '0'));

  signal read_a1_reg : std_logic_vector(31 downto 0) := (others => '0');
  signal read_b1_reg : std_logic_vector(31 downto 0) := (others => '0');
  signal read_c1_reg : std_logic_vector(31 downto 0) := (others => '0');

  signal read_a2_reg : std_logic_vector(31 downto 0) := (others => '0');
  signal read_b2_reg : std_logic_vector(31 downto 0) := (others => '0');
  signal read_c2_reg : std_logic_vector(31 downto 0) := (others => '0');

  signal voted_r1 : std_logic_vector(31 downto 0);
  signal voted_r2 : std_logic_vector(31 downto 0);

  signal mismatch_r1 : std_logic;
  signal mismatch_r2 : std_logic;

  signal reg_out_data1_r : std_logic_vector(31 downto 0) := (others => '0');
  signal reg_out_data2_r : std_logic_vector(31 downto 0) := (others => '0');

  function majority3_vec(
    a : std_logic_vector(31 downto 0);
    b : std_logic_vector(31 downto 0);
    c : std_logic_vector(31 downto 0)
  ) return std_logic_vector is
    variable r : std_logic_vector(31 downto 0);
  begin
    for i in 0 to 31 loop
      r(i) := (a(i) and b(i)) or (a(i) and c(i)) or (b(i) and c(i));
    end loop;
    return r;
  end function;

begin

  voted_r1 <= majority3_vec(read_a1_reg, read_b1_reg, read_c1_reg);
  voted_r2 <= majority3_vec(read_a2_reg, read_b2_reg, read_c2_reg);

  mismatch_r1 <= '1' when (read_a1_reg /= read_b1_reg) or
                          (read_a1_reg /= read_c1_reg) or
                          (read_b1_reg /= read_c1_reg)
                 else '0';

  mismatch_r2 <= '1' when (read_a2_reg /= read_b2_reg) or
                          (read_a2_reg /= read_c2_reg) or
                          (read_b2_reg /= read_c2_reg)
                 else '0';

  regfile_tmr_error_o <= mismatch_r1 or mismatch_r2;

  --------------------------------------------------------------------
  -- Variant without self-heal
  --------------------------------------------------------------------
  gen_no_self_heal : if not G_SELF_HEAL generate
    process(clk)
      variable waddr_int   : integer range 0 to 31;
      variable raddr1_int  : integer range 0 to 31;
      variable raddr2_int  : integer range 0 to 31;
      variable fi_addr_int : integer range 0 to 31;
    begin
      if rising_edge(clk) then
        if rst = '1' then
          regfile_a       <= (others => (others => '0'));
          regfile_b       <= (others => (others => '0'));
          regfile_c       <= (others => (others => '0'));

          read_a1_reg     <= (others => '0');
          read_b1_reg     <= (others => '0');
          read_c1_reg     <= (others => '0');
          read_a2_reg     <= (others => '0');
          read_b2_reg     <= (others => '0');
          read_c2_reg     <= (others => '0');

          reg_out_data1_r <= (others => '0');
          reg_out_data2_r <= (others => '0');

        else
          waddr_int   := to_integer(unsigned(reg_write_addr));
          raddr1_int  := to_integer(unsigned(reg_read_addr1));
          raddr2_int  := to_integer(unsigned(reg_read_addr2));
          fi_addr_int := to_integer(unsigned(fi_rf_addr_i));

          ----------------------------------------------------------------
          -- write / optional fault injection
          ----------------------------------------------------------------
          if we = '1' and reg_write_addr /= "00000" then
            regfile_a(waddr_int) <= reg_in_data;
            regfile_b(waddr_int) <= reg_in_data;
            regfile_c(waddr_int) <= reg_in_data;

          elsif G_FAULT_INJECT and fi_rf_strobe_i = '1' and fi_rf_addr_i /= "00000" then
            case fi_rf_target_i is
              when "00" =>
                regfile_a(fi_addr_int) <= regfile_a(fi_addr_int) xor fi_rf_mask_i;
              when "01" =>
                regfile_b(fi_addr_int) <= regfile_b(fi_addr_int) xor fi_rf_mask_i;
              when "10" =>
                regfile_c(fi_addr_int) <= regfile_c(fi_addr_int) xor fi_rf_mask_i;
              when others =>
                null;
            end case;
          end if;

          ----------------------------------------------------------------
          -- synchronous reads
          ----------------------------------------------------------------
          if raddr1_int = 0 then
            read_a1_reg <= (others => '0');
            read_b1_reg <= (others => '0');
            read_c1_reg <= (others => '0');
          else
            read_a1_reg <= regfile_a(raddr1_int);
            read_b1_reg <= regfile_b(raddr1_int);
            read_c1_reg <= regfile_c(raddr1_int);
          end if;

          if raddr2_int = 0 then
            read_a2_reg <= (others => '0');
            read_b2_reg <= (others => '0');
            read_c2_reg <= (others => '0');
          else
            read_a2_reg <= regfile_a(raddr2_int);
            read_b2_reg <= regfile_b(raddr2_int);
            read_c2_reg <= regfile_c(raddr2_int);
          end if;

          ----------------------------------------------------------------
          -- registered outputs with write-through bypass
          ----------------------------------------------------------------
          if we = '1' and reg_write_addr /= "00000" and reg_write_addr = reg_read_addr1 then
            reg_out_data1_r <= reg_in_data;
          elsif reg_read_addr1 = "00000" then
            reg_out_data1_r <= (others => '0');
          else
            reg_out_data1_r <= voted_r1;
          end if;

          if we = '1' and reg_write_addr /= "00000" and reg_write_addr = reg_read_addr2 then
            reg_out_data2_r <= reg_in_data;
          elsif reg_read_addr2 = "00000" then
            reg_out_data2_r <= (others => '0');
          else
            reg_out_data2_r <= voted_r2;
          end if;
        end if;
      end if;
    end process;
  end generate;

  --------------------------------------------------------------------
  -- Variant with self-heal
  --------------------------------------------------------------------
  gen_self_heal : if G_SELF_HEAL generate
    signal read_addr1_reg : std_logic_vector(4 downto 0) := (others => '0');
    signal read_addr2_reg : std_logic_vector(4 downto 0) := (others => '0');
  begin
    process(clk)
      variable waddr_int   : integer range 0 to 31;
      variable raddr1_int  : integer range 0 to 31;
      variable raddr2_int  : integer range 0 to 31;
      variable fi_addr_int : integer range 0 to 31;
    begin
      if rising_edge(clk) then
        if rst = '1' then
          regfile_a       <= (others => (others => '0'));
          regfile_b       <= (others => (others => '0'));
          regfile_c       <= (others => (others => '0'));

          read_addr1_reg  <= (others => '0');
          read_addr2_reg  <= (others => '0');

          read_a1_reg     <= (others => '0');
          read_b1_reg     <= (others => '0');
          read_c1_reg     <= (others => '0');
          read_a2_reg     <= (others => '0');
          read_b2_reg     <= (others => '0');
          read_c2_reg     <= (others => '0');

          reg_out_data1_r <= (others => '0');
          reg_out_data2_r <= (others => '0');

        else
          waddr_int   := to_integer(unsigned(reg_write_addr));
          raddr1_int  := to_integer(unsigned(reg_read_addr1));
          raddr2_int  := to_integer(unsigned(reg_read_addr2));
          fi_addr_int := to_integer(unsigned(fi_rf_addr_i));

          read_addr1_reg <= reg_read_addr1;
          read_addr2_reg <= reg_read_addr2;

          ----------------------------------------------------------------
          -- write / optional FI / self-heal
          ----------------------------------------------------------------
          if we = '1' and reg_write_addr /= "00000" then
            regfile_a(waddr_int) <= reg_in_data;
            regfile_b(waddr_int) <= reg_in_data;
            regfile_c(waddr_int) <= reg_in_data;

          elsif G_FAULT_INJECT and fi_rf_strobe_i = '1' and fi_rf_addr_i /= "00000" then
            case fi_rf_target_i is
              when "00" =>
                regfile_a(fi_addr_int) <= regfile_a(fi_addr_int) xor fi_rf_mask_i;
              when "01" =>
                regfile_b(fi_addr_int) <= regfile_b(fi_addr_int) xor fi_rf_mask_i;
              when "10" =>
                regfile_c(fi_addr_int) <= regfile_c(fi_addr_int) xor fi_rf_mask_i;
              when others =>
                null;
            end case;

          elsif read_addr1_reg /= "00000" and mismatch_r1 = '1' then
            regfile_a(to_integer(unsigned(read_addr1_reg))) <= voted_r1;
            regfile_b(to_integer(unsigned(read_addr1_reg))) <= voted_r1;
            regfile_c(to_integer(unsigned(read_addr1_reg))) <= voted_r1;

          elsif read_addr2_reg /= "00000" and mismatch_r2 = '1' then
            regfile_a(to_integer(unsigned(read_addr2_reg))) <= voted_r2;
            regfile_b(to_integer(unsigned(read_addr2_reg))) <= voted_r2;
            regfile_c(to_integer(unsigned(read_addr2_reg))) <= voted_r2;
          end if;

          ----------------------------------------------------------------
          -- synchronous reads
          ----------------------------------------------------------------
          if raddr1_int = 0 then
            read_a1_reg <= (others => '0');
            read_b1_reg <= (others => '0');
            read_c1_reg <= (others => '0');
          else
            read_a1_reg <= regfile_a(raddr1_int);
            read_b1_reg <= regfile_b(raddr1_int);
            read_c1_reg <= regfile_c(raddr1_int);
          end if;

          if raddr2_int = 0 then
            read_a2_reg <= (others => '0');
            read_b2_reg <= (others => '0');
            read_c2_reg <= (others => '0');
          else
            read_a2_reg <= regfile_a(raddr2_int);
            read_b2_reg <= regfile_b(raddr2_int);
            read_c2_reg <= regfile_c(raddr2_int);
          end if;

          ----------------------------------------------------------------
          -- registered outputs with write-through bypass
          ----------------------------------------------------------------
          if we = '1' and reg_write_addr /= "00000" and reg_write_addr = reg_read_addr1 then
            reg_out_data1_r <= reg_in_data;
          elsif reg_read_addr1 = "00000" then
            reg_out_data1_r <= (others => '0');
          else
            reg_out_data1_r <= voted_r1;
          end if;

          if we = '1' and reg_write_addr /= "00000" and reg_write_addr = reg_read_addr2 then
            reg_out_data2_r <= reg_in_data;
          elsif reg_read_addr2 = "00000" then
            reg_out_data2_r <= (others => '0');
          else
            reg_out_data2_r <= voted_r2;
          end if;
        end if;
      end if;
    end process;
  end generate;

  reg_out_data1 <= reg_out_data1_r;
  reg_out_data2 <= reg_out_data2_r;

end rtl;